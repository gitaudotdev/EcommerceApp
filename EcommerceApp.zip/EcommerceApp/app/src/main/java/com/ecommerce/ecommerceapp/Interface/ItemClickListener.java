package com.ecommerce.ecommerceapp.Interface;

import android.view.View;

public interface ItemClickListener {
    void onClick(View v);
}
