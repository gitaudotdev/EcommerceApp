package com.ecommerce.ecommerceapp.Model;

public class Drink {
    public String ID;
    public String Name;
    public String Link;
    public String Price;
    public String MenuId;
}
