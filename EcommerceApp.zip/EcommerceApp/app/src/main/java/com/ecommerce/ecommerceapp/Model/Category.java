package com.ecommerce.ecommerceapp.Model;

public class Category {
    public String ID ;
    public String Name;
    public String Link;
}
