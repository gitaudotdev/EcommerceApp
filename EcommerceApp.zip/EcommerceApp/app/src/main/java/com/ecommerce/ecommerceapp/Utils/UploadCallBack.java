package com.ecommerce.ecommerceapp.Utils;

public interface UploadCallBack {
    void onProgressUpdate(int percentage);
}
